insert into student
values(10001,'Jivesh', 'E1234567');

insert into student
values(10002,'Kumar', 'A1234568');